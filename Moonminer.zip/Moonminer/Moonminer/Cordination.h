#pragma once
#include <vector>
struct pair
{
	int x,y;
};

class Cordination
{
	std::vector<pair> vCord;
public:

};